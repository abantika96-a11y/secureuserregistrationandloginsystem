<?php $config = require __DIR__ . '/../../config/config.php'; $base = rtrim($config['base_url'], '/'); ?>
<section class="hero">
  <div class="hero-text">
    <h1>Secure User Registration and Login System</h1>
    <p>This project implements a secure and modular user authentication system using PHP, MySQL, and OOP best practices.</p>
    <div class="hero-actions">
      <a class="btn primary" href="<?= $base ?>/register">Get started</a>
      <a class="btn" href="<?= $base ?>/login">Sign in</a>
    </div>
  </div>
  <canvas id="securityCanvas"></canvas>
</section>

<script src="https://unpkg.com/three@0.158.0/build/three.min.js"></script>
<script src="<?= $base ?>/assets/js/landing3d.js"></script>
